plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.emil.tienda"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.emil.tienda"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    // Usa implementation(platform("...")) con comillas dobles
    implementation(platform("com.google.firebase:firebase-bom:32.7.1")) // O versión más reciente

    // Usa implementation("...") con comillas dobles
    implementation("com.google.firebase:firebase-firestore")
}