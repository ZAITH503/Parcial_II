package com.emil.tienda;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EmilDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Emil.db";
    private static final int DATABASE_VERSION = 1;

    public EmilDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE productos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre TEXT, " +
                "precio REAL, " +
                "costo REAL, " +
                "stock INTEGER, " +
                "ganancia REAL)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS productos");
        onCreate(db);
    }

    public void agregarProducto(Producto producto) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", producto.getNombre());
        values.put("precio", producto.getPrecio());
        values.put("costo", producto.getCosto());
        values.put("stock", producto.getStock());
        values.put("ganancia", producto.getGanancia());
        db.insert("productos", null, values);
        db.close();
    }
}

