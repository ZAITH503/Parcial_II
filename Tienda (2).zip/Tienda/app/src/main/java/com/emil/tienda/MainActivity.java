package com.emil.tienda;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query; // Importante para ordenar

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    // UI Elements
    private EditText editTextNombre;
    private EditText editTextPrecio;
    private Button buttonAgregar;
    private RecyclerView recyclerViewProductos;

    // Firebase
    private FirebaseFirestore db;
    private CollectionReference productosRef;
    private ListenerRegistration listenerProductos; // Para manejar el listener en tiempo real

    // RecyclerView
    private ProductoAdapter adapter;
    private List<Producto> listaProductos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar UI
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextPrecio = findViewById(R.id.editTextPrecio);
        buttonAgregar = findViewById(R.id.buttonAgregar);
        recyclerViewProductos = findViewById(R.id.recyclerViewProductos);

        // Inicializar Firebase
        db = FirebaseFirestore.getInstance();
        // "productos" será el nombre de tu colección en Firestore
        productosRef = db.collection("productos");

        // Configurar RecyclerView
        listaProductos = new ArrayList<>();
        adapter = new ProductoAdapter(); // Le pasamos la lista al adaptador
        recyclerViewProductos.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewProductos.setAdapter(adapter);

        // Configurar Listener del Botón
        buttonAgregar.setOnClickListener(view -> agregarProducto());

        // Cargar/Escuchar productos desde Firestore
        escucharCambiosProductos();
    }

    private void agregarProducto() {
        String nombre = editTextNombre.getText().toString().trim();
        String precioStr = editTextPrecio.getText().toString().trim();

        if (nombre.isEmpty()) {
            editTextNombre.setError("Nombre requerido");
            editTextNombre.requestFocus();
            return;
        }
        if (precioStr.isEmpty()) {
            editTextPrecio.setError("Precio requerido");
            editTextPrecio.requestFocus();
            return;
        }

        double precio;
        try {
            precio = Double.parseDouble(precioStr);
            if (precio < 0) {
                editTextPrecio.setError("Precio no puede ser negativo");
                editTextPrecio.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            editTextPrecio.setError("Precio inválido");
            editTextPrecio.requestFocus();
            return;
        }

        // Crea el objeto Producto (sin ID, Firestore lo genera)
        Producto nuevoProducto = new Producto(nombre, precio);

        // Añade el documento a la colección "productos"
        productosRef.add(nuevoProducto)
                .addOnSuccessListener(documentReference -> {
                    Log.d(TAG, "Producto agregado con ID: " + documentReference.getId());
                    Toast.makeText(MainActivity.this, "Producto agregado", Toast.LENGTH_SHORT).show();
                    // Limpiar campos
                    editTextNombre.setText("");
                    editTextPrecio.setText("");
                    editTextNombre.requestFocus(); // Poner foco de nuevo en nombre
                })
                .addOnFailureListener(e -> {
                    Log.w(TAG, "Error agregando producto", e);
                    Toast.makeText(MainActivity.this, "Error al agregar producto", Toast.LENGTH_SHORT).show();
                });
    }

    // Método para escuchar cambios en tiempo real
    private void escucharCambiosProductos() {
        // Puedes ordenar los resultados, por ejemplo, por nombre
        // Query query = productosRef.orderBy("nombre", Query.Direction.ASCENDING);
        // O por precio: Query query = productosRef.orderBy("precio", Query.Direction.DESCENDING);
        Query query = productosRef; // Sin ordenar por ahora

        listenerProductos = query.addSnapshotListener((snapshots, e) -> {
            if (e != null) {
                Log.w(TAG, "Error al escuchar cambios.", e);
                Toast.makeText(MainActivity.this, "Error al cargar productos", Toast.LENGTH_SHORT).show();
                return;
            }

            if (snapshots != null) {
                Log.d(TAG, "Nuevos datos recibidos. Cambios: " + snapshots.getDocumentChanges().size());
                listaProductos.clear(); // Limpiamos la lista actual para reconstruirla
                for (DocumentChange dc : snapshots.getDocumentChanges()) {
                    switch (dc.getType()) {
                        case ADDED:
                            // Convertir el documento a objeto Producto
                            Producto prodAdd = dc.getDocument().toObject(Producto.class);
                            prodAdd.setId(dc.getDocument().getId()); // Asigna el ID del documento
                            listaProductos.add(prodAdd);
                            Log.d(TAG, "Producto AÑADIDO: " + prodAdd.toString());
                            break;
                        case MODIFIED:
                            // (Opcional) Manejar modificaciones si permites editar
                            Producto prodMod = dc.getDocument().toObject(Producto.class);
                            prodMod.setId(dc.getDocument().getId());
                            Log.d(TAG, "Producto MODIFICADO: " + prodMod.toString());
                            // Encuentra y actualiza el producto en tu lista local si es necesario
                            // (Para este ejemplo simple, recargar todo funciona bien)
                            break;
                        case REMOVED:
                            // (Opcional) Manejar eliminaciones si permites borrar
                            String idRemoved = dc.getDocument().getId();
                            Log.d(TAG, "Producto ELIMINADO ID: " + idRemoved);
                            // Encuentra y elimina el producto de tu lista local si es necesario
                            break;
                    }
                }
                // Después de procesar los cambios, recargamos toda la lista actualizada
                cargarListaCompleta();
            } else {
                Log.d(TAG, "Snapshot nulo recibido.");
            }
        });
    }

    // Método auxiliar para cargar la lista completa (llamado por el listener)
    private void cargarListaCompleta() {
        productosRef.orderBy("nombre", Query.Direction.ASCENDING) // Ordenar al mostrar
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    listaProductos.clear();
                    for(var doc : queryDocumentSnapshots.getDocuments()) {
                        Producto p = doc.toObject(Producto.class);
                        if (p != null) {
                            p.setId(doc.getId());
                            listaProductos.add(p);
                        }
                    }
                    adapter.setProductos(listaProductos); // Actualiza el RecyclerView
                    Log.d(TAG, "Lista actualizada en RecyclerView con " + listaProductos.size() + " productos.");
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error obteniendo la lista completa", e);
                });
    }


    // Es buena práctica detener el listener cuando la actividad ya no está visible
    @Override
    protected void onStop() {
        super.onStop();
        if (listenerProductos != null) {
            listenerProductos.remove(); // Detiene la escucha activa
            Log.d(TAG,"Listener de productos detenido.");
        }
    }

    // Vuelve a iniciar el listener si la actividad vuelve a primer plano
    @Override
    protected void onStart() {
        super.onStart();
        // Volvemos a registrar el listener si no estaba ya activo
        // La llamada a cargarListaCompleta dentro del listener se encargará de traer los datos
        if (listenerProductos == null) {
            escucharCambiosProductos();
            Log.d(TAG,"Listener de productos reiniciado.");
        } else {
            // Si ya existe, forzamos una recarga inicial por si acaso hubo cambios offline
            cargarListaCompleta();
        }
    }
}