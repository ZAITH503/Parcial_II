package com.emil.tienda;



import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ProductoAdapter extends RecyclerView.Adapter<ProductoAdapter.ProductoViewHolder> {

    private List<Producto> listaProductos = new ArrayList<>();

    @NonNull
    @Override
    public ProductoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_producto, parent, false); // Usa tu layout de item
        return new ProductoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductoViewHolder holder, int position) {
        Producto productoActual = listaProductos.get(position);
        holder.textViewNombre.setText(productoActual.getNombre());
        // Formatea el precio para mostrarlo correctamente
        holder.textViewPrecio.setText(String.format(Locale.getDefault(), "Precio: $%.2f", productoActual.getPrecio()));
    }

    @Override
    public int getItemCount() {
        return listaProductos.size();
    }

    // Método para actualizar la lista de productos en el adaptador
    public void setProductos(List<Producto> nuevosProductos) {
        this.listaProductos = nuevosProductos;
        notifyDataSetChanged(); // Notifica al RecyclerView que los datos cambiaron
    }

    // ViewHolder interno
    static class ProductoViewHolder extends RecyclerView.ViewHolder {
        TextView textViewNombre;
        TextView textViewPrecio;

        public ProductoViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewNombre = itemView.findViewById(R.id.textViewItemNombre);
            textViewPrecio = itemView.findViewById(R.id.textViewItemPrecio);
        }
    }
}